const public_key = "pk_test_bb18a2e51d82edaf36aa443679756267d6fef396",
  ccrit_key = "sk_test_3937d46911e47f3c6609c40f79b5f4dbef1210f6";

export { public_key, ccrit_key };
